exports.default = {
    domain: "www.baidu.com"
};