module.exports = {
    apps: [
        {
            name: "traffic-node",
            script: "./dist/server.js",
            watch: ["./dist","./ssl-prod"],
            output: "./logs/out.log",
            error: "./logs/error.log",
            time: true,
            // instances: 4,
            args: ["--color"],
            env_prod: {
                // DB_HOST: "rm-wz95x4n2xi81t1gc6so.mysql.rds.aliyuncs.com",
                DB_HOST: "13.212.107.248",
                DB_PORT: 3306,
                DB_USER: "mysql",
                DB_PWD: "Wn_0701#",
                REDIS_PWD: "",
                ENV: "prod"
            },
            env_test: {
                // DB_HOST: "rm-wz95x4n2xi81t1gc6so.mysql.rds.aliyuncs.com",
                DB_HOST: "127.0.0.1",
                DB_PORT: 3306,
                DB_USER: "",
                DB_PWD: "",
                REDIS_PWD: "",
                ENV: "test"
            },
            env_dev: {
                // DB_HOST: "rm-wz95x4n2xi81t1gc6so.mysql.rds.aliyuncs.com",
                DB_HOST: "127.0.0.1",
                DB_PORT: 3306,
                DB_USER: "root",
                DB_PWD: "",
                ENV: "dev"
            },
        }
    ],

    deploy: {
        production: {
            user: "SSH_USERNAME",
            host: "SSH_HOSTMACHINE",
            ref: "origin/master",
            repo: "GIT_REPOSITORY",
            path: "DESTINATION_PATH",
            "pre-deploy-local": "",
            "post-deploy": "npm install && pm2 reload ecosystem.config.js --env production",
            "pre-setup": ""
        }
    }
};
